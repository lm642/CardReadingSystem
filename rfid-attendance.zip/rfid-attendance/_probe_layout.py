"""临时探针：验证设置页布局 + 保存/重启/校验 是否好用。"""
import tkinter as tk
import attendance as A

# 弹窗改成打印，避免测试时被阻塞
A.messagebox.showerror = lambda *a, **k: print("  [对话框-错误]", (a[1] if len(a) > 1 else a))
A.messagebox.showinfo = lambda *a, **k: print("  [对话框-提示]", (a[1] if len(a) > 1 else a))
A.messagebox.showwarning = lambda *a, **k: print("  [对话框-警告]", (a[1] if len(a) > 1 else a))

root = tk.Tk()
app = A.AppUI(root)
app.nb.select(app.tab_set)
root.update_idletasks(); root.update()

nb_y, nb_h = app.nb.winfo_rooty(), app.nb.winfo_height()
print("可视区 bottom =", nb_y + nb_h)

for name, w in (("底部保存按钮", app.btn_save_set), ("试听按钮", None)):
    if w is None:
        continue
    print(f"{name}: bottom = {w.winfo_rooty() + w.winfo_height()} -> "
          f"{'✅ 可见' if w.winfo_rooty() + w.winfo_height() <= nb_y + nb_h else '❌ 仍被挤出'}")

# 顶部那个保存按钮
tops = [w for w in app.tab_set.winfo_children()]
canvas = None
for w in app.nb.winfo_children():
    pass

print("\n--- 1) 改动数值后是否提示未保存 ---")
app.var_set["buzzer_ms"].set("300")
print("  set_dirty =", app.set_dirty, "|", app.lbl_set_msg.cget("text"))
app.var_set["interval_minutes"].set("45")
print("  再改一项 ->", app.lbl_set_msg.cget("text"))

print("\n--- 2) 填非法值保存 ---")
app.var_set["interval_minutes"].set("abc")
app._save_settings()
print("  库中间隔值（应仍是旧值，未被写坏）= 45?", app.db.get_setting("interval_minutes"))

print("\n--- 3) 越界值 ---")
app.var_set["poll_interval"].set("99")
app._save_settings()

print("\n--- 4) 合法值保存并重启读卡器 ---")
app.var_set["poll_interval"].set("0.2")
app.var_set["interval_minutes"].set("45")
app._save_settings()
print("  库中 interval_minutes =", app.db.get_setting("interval_minutes"))
print("  库中 poll_interval    =", app.db.get_setting("poll_interval"))
print("  库中 buzzer_ms        =", app.db.get_setting("buzzer_ms"))
print("  set_dirty =", app.set_dirty, "|", app.lbl_set_msg.cget("text"))

print("\n--- 5) 还原按钮 ---")
app._revert_settings()
print("  interval_minutes 回填 =", app.var_set["interval_minutes"].get(),
      "| set_dirty =", app.set_dirty)

print("\n--- 6) Ctrl+S 热键 ---")
app.var_set["debounce_seconds"].set("5")
root.event_generate("<Control-s>")
root.update()
print("  触发后库中 debounce_seconds =", app.db.get_setting("debounce_seconds"))

print("\n--- 7) 滚动区域 ---")
def find_canvas(w):
    for c in w.winfo_children():
        if isinstance(c, tk.Canvas):
            return c
        r = find_canvas(c)
        if r:
            return r
    return None
cv = find_canvas(app.tab_set)
print("  canvas scrollregion =", cv.cget("scrollregion") if cv else "未找到")
if cv:
    cv.yview_moveto(1.0)
    root.update()
    print("  滚到底后保存按钮 y =", app.btn_save_set.winfo_rooty(), "（操作条常驻，不受滚动影响）")

root.destroy()
